package com.practice.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GoogleSearchPage extends BasePage{

	@FindBy(id = "lst-ib")
	WebElement searchInput;
	
	
	public GoogleSearchPage(WebDriver driver) {
		super(driver);
	}
	
	public void enterSearchInput(String input) {
		searchInput.sendKeys(input+Keys.ENTER);
	}

}
