package com.practice.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class GoogleSearchResultPage extends BasePage {

	@FindBy(css = "#search a")
	List<WebElement> searchLinks;

	public GoogleSearchResultPage(WebDriver driver) {
		super(driver);
	}

	public void validateSearch(String key) {
		for (WebElement link : searchLinks) {
			if (link.isDisplayed()) {
				Assert.assertTrue(link.getText().trim().toLowerCase().contains(key.toLowerCase()), "Insvalid search result : Test failed");
				break;
			}
		}
	}

}
