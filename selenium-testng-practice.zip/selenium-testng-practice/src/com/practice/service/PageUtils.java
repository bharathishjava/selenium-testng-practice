package com.practice.service;

import org.openqa.selenium.WebDriver;

import com.practice.pages.GoogleSearchPage;
import com.practice.pages.GoogleSearchResultPage;

public class PageUtils {
	private WebDriver driver;
	private GoogleSearchPage googleSearchPage;
	private GoogleSearchResultPage googleSearchResultPage;
	
	public PageUtils(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public GoogleSearchPage getGoogleSearchPage() {
		if(googleSearchPage== null)
			googleSearchPage = new GoogleSearchPage(driver);
		return googleSearchPage;
	}
	public GoogleSearchResultPage getGoogleSearchResultPage() {
		if(googleSearchResultPage== null)
			googleSearchResultPage = new GoogleSearchResultPage(driver);
		return googleSearchResultPage;
	}
	
	
}
