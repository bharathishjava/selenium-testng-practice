package com.practice.tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class GoogleSearchTest extends BaseTest {
	
	@DataProvider(name = "keys")
	public String[][] getKeys(){
		return new String[][]{{"Java"},{"phone"}};
	}

	@Test(dataProvider="keys")
	public void googleSearchTest(String key) {
		driver.get("http://www.google.co.in/");
		//By creating objects
		/*GoogleSearchPage googleSearchPage = new GoogleSearchPage(driver);
		googleSearchPage.enterSearchInput("Java");
		GoogleSearchResultPage googleSearchResultPage = new GoogleSearchResultPage(driver);
		googleSearchResultPage.validateSearch("Java");*/
		
		//By using page util
		pageUtils.getGoogleSearchPage().enterSearchInput(key);
		pageUtils.getGoogleSearchResultPage().validateSearch(key);
	}
}
