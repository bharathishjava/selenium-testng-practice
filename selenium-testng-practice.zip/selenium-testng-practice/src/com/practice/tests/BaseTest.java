package com.practice.tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import com.practice.service.PageUtils;

public class BaseTest {

	protected WebDriver driver;
	protected PageUtils pageUtils;

	@BeforeTest
	public void initialize() {
		try {
			driver = new ChromeDriver();
		} catch (Exception e) {
			Assert.fail("Driver has not initialized..");
		}
		pageUtils = new PageUtils(driver);
	}

	@AfterTest
	public void wrapUp() {
		if (driver != null) {
			driver.close();
			driver.quit();
		}
	}
}
